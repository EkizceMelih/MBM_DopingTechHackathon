using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace hackathondeneme.Pages
{
    public class GenerateQuestionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
