using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace hackathondeneme.Views.Home
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
