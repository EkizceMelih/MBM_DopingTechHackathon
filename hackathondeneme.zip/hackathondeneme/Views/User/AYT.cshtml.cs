using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace hackathondeneme.View.User
{
    public class AYTModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
