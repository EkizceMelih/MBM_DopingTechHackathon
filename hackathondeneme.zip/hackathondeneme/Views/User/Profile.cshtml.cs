using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace hackathondeneme.Views.User
{
    public class ProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
