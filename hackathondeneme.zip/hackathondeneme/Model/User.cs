﻿namespace hackathondeneme.Model
{
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public float tyt_turkce { get; set; }
        public float tyt_mat { get; set; }
        public float tyt_fizik { get; set; }
        public float tyt_kimya { get; set; }
        public float tyt_biyoloji { get; set; }
        public float tyt_tarih { get; set; }
        public float tyt_cografya { get; set; }
        public float tyt_din { get; set; }
        public float tyt_felsefe { get; set; }
        public float ayt_mat { get; set; }
        public float ayt_fizik { get; set; }
        public float ayt_kimya { get; set; }
        public float ayt_biyoloji { get; set; }
        public int TargetRank { get; set; }  // Kullanıcının hedeflediği sıralama
    }
}
