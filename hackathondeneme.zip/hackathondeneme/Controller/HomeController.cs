﻿using Microsoft.AspNetCore.Mvc;

namespace hackathondeneme.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
