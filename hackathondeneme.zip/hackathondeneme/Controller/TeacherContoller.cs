﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace hackathondeneme.Controllers
{
    public class TeacherController : Controller
    {
        public IActionResult ExamAnalysis()
        {
            // Örnek soru analiz verileri
            var questionAnalysis = new List<QuestionStat>
            {
                new QuestionStat { QuestionID = 1, Subject = "Matematik", Topic = "Fonksiyonlar", CorrectPercentage = 65, CorrectAnswer = "B" },
                new QuestionStat { QuestionID = 2, Subject = "Matematik", Topic = "Geometri", CorrectPercentage = 52, CorrectAnswer = "C" },
                new QuestionStat { QuestionID = 3, Subject = "Fizik", Topic = "Elektrik", CorrectPercentage = 78, CorrectAnswer = "D" },
                new QuestionStat { QuestionID = 4, Subject = "Kimya", Topic = "Mol Kavramı", CorrectPercentage = 40, CorrectAnswer = "A" },
                new QuestionStat { QuestionID = 5, Subject = "Biyoloji", Topic = "Hücre", CorrectPercentage = 85, CorrectAnswer = "E" },
                new QuestionStat { QuestionID = 6, Subject = "Fizik", Topic = "Hareket", CorrectPercentage = 30, CorrectAnswer = "C" },
                new QuestionStat { QuestionID = 7, Subject = "Kimya", Topic = "Asit-Baz Dengesi", CorrectPercentage = 25, CorrectAnswer = "B" }
            };

            // I want to changed dynamic lesson threshold but I dont have a dataset that's why
            // I determined the threshold as %55 but in the future this ratio will be dynamic absolutely
            var lowPerformingQuestions = questionAnalysis.Where(q => q.CorrectPercentage < 55).ToList();

            var viewModel = new TeacherViewModel
            {
                QuestionAnalysis = questionAnalysis,
                LowPerformingQuestions = lowPerformingQuestions
            };

            return View(viewModel);
        }
    }

    public class QuestionStat
    {
        public int QuestionID { get; set; }
        public string Subject { get; set; }
        public string Topic { get; set; }
        public double CorrectPercentage { get; set; }
        public string CorrectAnswer { get; set; }
    }

    public class TeacherViewModel
    {
        public List<QuestionStat> QuestionAnalysis { get; set; }
        public List<QuestionStat> LowPerformingQuestions { get; set; }
    }
}
