﻿using Microsoft.AspNetCore.Mvc;
using Amazon.BedrockRuntime;
using Amazon.Textract;
using Amazon.BedrockRuntime.Model;
using Amazon.Textract.Model;
using System.Text;
using Newtonsoft.Json;

namespace hackathondeneme.Controllers
{
    [ApiController]
    [Route("api/ai")]
    public class AIController : ControllerBase
    {
        private readonly AmazonTextractClient _textractClient;
        private readonly AmazonBedrockRuntimeClient _bedrockClient;

        public AIController() // Amazon Bedrock Region US-East1 Virginia
        {
            _textractClient = new AmazonTextractClient(Amazon.RegionEndpoint.USEast1);
            _bedrockClient = new AmazonBedrockRuntimeClient(Amazon.RegionEndpoint.USEast1);
        }

        [HttpPost("GenerateNewQuestion")] //Generative Question Maker from Claude3 Haiku
        public async Task<IActionResult> GenerateNewQuestion([FromForm] IFormFile image)
        {
            if (image == null || image.Length == 0)
                return BadRequest(new { error = "⚠️ Lütfen geçerli bir resim yükleyin!" });

            try
            {
                string extractedText = await ExtractTextFromImage(image);
                if (string.IsNullOrWhiteSpace(extractedText))
                    return BadRequest(new { error = "⚠️ Görselden metin çıkarılamadı. Lütfen farklı bir görsel deneyin." });

                string generatedQuestion = await GenerateNewMathQuestion(extractedText);
                if (string.IsNullOrWhiteSpace(generatedQuestion))
                    return BadRequest(new { error = "⚠️ Claude 3 Haiku yeni bir soru üretemedi. Lütfen tekrar deneyin." });

                return Ok(new { extracted_text = extractedText, generated_question = generatedQuestion });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = $"❌ Bir hata oluştu: {ex.Message}" });
            }
        }

        private async Task<string> ExtractTextFromImage(IFormFile image)
        {
            using var stream = image.OpenReadStream();
            var request = new DetectDocumentTextRequest
            {
                Document = new Document { Bytes = new MemoryStream() }
            };

            await stream.CopyToAsync(request.Document.Bytes);

            var response = await _textractClient.DetectDocumentTextAsync(request);
            StringBuilder extractedText = new StringBuilder();
            foreach (var block in response.Blocks.Where(b => b.BlockType == "LINE"))
            {
                extractedText.AppendLine(block.Text);
            }

            return extractedText.ToString().Trim();
        }

        private async Task<string> GenerateNewMathQuestion(string originalQuestion)
        {
            string prompt = $@"
            I have extracted a math problem from an image:
            ""{originalQuestion}""

            Please generate a similar but different math question that tests the same concept.
            ";

            var payload = new
            {
                anthropic_version = "bedrock-2023-05-31",
                max_tokens = 300,
                messages = new[] { new { role = "user", content = new[] { new { type = "text", text = prompt } } } }
            };

            var request = new InvokeModelRequest
            {
                ModelId = "anthropic.claude-3-haiku-20240307-v1:0",
                ContentType = "application/json",
                Accept = "application/json",
                Body = new MemoryStream(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(payload)))
            };

            var response = await _bedrockClient.InvokeModelAsync(request);
            using var reader = new StreamReader(response.Body);
            var responseBody = await reader.ReadToEndAsync();
            var responseJson = JsonConvert.DeserializeObject<dynamic>(responseBody);

            return responseJson?.content[0]?.text ?? "Yeni soru üretilemedi.";
        }
    }
}
