﻿using Microsoft.AspNetCore.Mvc;
using hackathondeneme.Model;
using System.Collections.Generic;
using System.Linq;
using Amazon.BedrockRuntime;
using Amazon.Textract;
using Amazon.BedrockRuntime.Model;
using Amazon.Textract.Model;
using System.Text;
using Newtonsoft.Json;
namespace hackathondeneme.Controllers
{
    public class UserController : Controller
    {
        private readonly AmazonTextractClient _textractClient;
        private readonly AmazonBedrockRuntimeClient _bedrockClient;

        public UserController()
        {
            _textractClient = new AmazonTextractClient(Amazon.RegionEndpoint.USEast1);
            _bedrockClient = new AmazonBedrockRuntimeClient(Amazon.RegionEndpoint.USEast1);
        }

        [HttpPost]
        public async Task<IActionResult> GenerateNewQuestion(IFormFile image)
        {
            if (image == null || image.Length == 0)
                return Json(new { error = "Lütfen bir resim yükleyin." });

            // 📌 1. Görselden metin çıkar (AWS Textract)
            string extractedText = await ExtractTextFromImage(image);

            if (string.IsNullOrEmpty(extractedText))
                return Json(new { error = "Görselden metin çıkarılamadı." });

            // 📌 2. Claude 3 Haiku ile yeni matematik sorusu üret
            string newQuestion = await GenerateNewMathQuestion(extractedText);

            return Json(new
            {
                extracted_text = extractedText,
                generated_question = newQuestion
            });
        }
        private async Task<string> ExtractTextFromImage(IFormFile image)
        {
            using var stream = image.OpenReadStream();
            var request = new DetectDocumentTextRequest
            {
                Document = new Document { Bytes = new MemoryStream() }
            };

            await stream.CopyToAsync(request.Document.Bytes);

            var response = await _textractClient.DetectDocumentTextAsync(request);

            StringBuilder extractedText = new StringBuilder();
            foreach (var block in response.Blocks.Where(b => b.BlockType == "LINE"))
            {
                extractedText.AppendLine(block.Text);
            }

            return extractedText.ToString().Trim();
        }

        private async Task<string> GenerateNewMathQuestion(string originalQuestion)
        {
            string prompt = $@"
            I have extracted a math problem from an image:
            ""{originalQuestion}""

            Please generate a similar but different math question that tests the same concept.
            ";

            var payload = new
            {
                anthropic_version = "bedrock-2023-05-31",
                max_tokens = 300,
                messages = new[]
                {
                    new { role = "user", content = new[] { new { type = "text", text = prompt } } }
                }
            };

            var request = new InvokeModelRequest
            {
                ModelId = "anthropic.claude-3-haiku-20240307-v1:0",
                ContentType = "application/json",
                Accept = "application/json",
                Body = new MemoryStream(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(payload)))
            };

            var response = await _bedrockClient.InvokeModelAsync(request);
            using var reader = new StreamReader(response.Body);
            var responseBody = await reader.ReadToEndAsync();
            var responseJson = JsonConvert.DeserializeObject<dynamic>(responseBody);

            return responseJson?.content[0]?.text ?? "Yeni soru üretilemedi.";
        }


        private static List<User> users = new List<User>
        {
            new User { UserId = 1, Name = "A** Y**", TargetRank = 1000, tyt_turkce = 30, tyt_mat = 25, tyt_fizik = 5, tyt_kimya = 8, tyt_biyoloji = 6, tyt_tarih = 9, tyt_cografya = 7, tyt_din = 4, tyt_felsefe = 3, ayt_mat = 20, ayt_fizik = 8, ayt_kimya = 7, ayt_biyoloji = 6 },
            new User { UserId = 2, Name = "Z** K**", TargetRank = 5000, tyt_turkce = 28, tyt_mat = 27, tyt_fizik = 6, tyt_kimya = 7, tyt_biyoloji = 6, tyt_tarih = 8, tyt_cografya = 6, tyt_din = 7, tyt_felsefe = 5, ayt_mat = 21, ayt_fizik = 7, ayt_kimya = 6, ayt_biyoloji = 5 },
            new User { UserId = 3, Name = "M** D**", TargetRank = 3000, tyt_turkce = 32, tyt_mat = 29, tyt_fizik = 7, tyt_kimya = 9, tyt_biyoloji = 8, tyt_tarih = 10, tyt_cografya = 8, tyt_din = 6, tyt_felsefe = 4, ayt_mat = 22, ayt_fizik = 9, ayt_kimya = 8, ayt_biyoloji = 7 },
            new User { UserId = 4, Name = "E** Ç**", TargetRank = 8000, tyt_turkce = 27, tyt_mat = 24, tyt_fizik = 5, tyt_kimya = 7, tyt_biyoloji = 5, tyt_tarih = 7, tyt_cografya = 5, tyt_din = 4, tyt_felsefe = 3, ayt_mat = 19, ayt_fizik = 6, ayt_kimya = 5, ayt_biyoloji = 4 },
            new User { UserId = 5, Name = "B** Ö**", TargetRank = 1500, tyt_turkce = 29, tyt_mat = 26, tyt_fizik = 6, tyt_kimya = 8, tyt_biyoloji = 7, tyt_tarih = 9, tyt_cografya = 7, tyt_din = 5, tyt_felsefe = 4, ayt_mat = 20, ayt_fizik = 7, ayt_kimya = 6, ayt_biyoloji = 5 }
        };

        public IActionResult TYT()
        {
            var user = users.First(); // İlk kullanıcıyı al
            var avgScores = new User
            {
                tyt_turkce = users.Average(u => u.tyt_turkce),
                tyt_mat = users.Average(u => u.tyt_mat),
                tyt_fizik = users.Average(u => u.tyt_fizik),
                tyt_kimya = users.Average(u => u.tyt_kimya),
                tyt_biyoloji = users.Average(u => u.tyt_biyoloji),
                tyt_tarih = users.Average(u => u.tyt_tarih),
                tyt_cografya = users.Average(u => u.tyt_cografya),
                tyt_din = users.Average(u => u.tyt_din),
                tyt_felsefe = users.Average(u => u.tyt_felsefe)
            };

            ViewBag.AvgScores = avgScores;
            return View(user);
        }

        public IActionResult AYT()
        {
            var user = users.First(); // İlk kullanıcıyı al
            var avgScores = new User
            {
                ayt_mat = users.Average(u => u.ayt_mat),
                ayt_fizik = users.Average(u => u.ayt_fizik),
                ayt_kimya = users.Average(u => u.ayt_kimya),
                ayt_biyoloji = users.Average(u => u.ayt_biyoloji)
            };

            ViewBag.AvgScores = avgScores;
            return View(user);
        }

        public IActionResult Profile(int id)
        {
            var user = users.FirstOrDefault(u => u.UserId == id);
            if (user == null)
            {
                return NotFound("Kullanıcı bulunamadı.");
            }

            return View(user);
        }
    }
}
